import streamlit as st
import pickle
import numpy as np

model = pickle.load(open("logistic_model.pkl", "rb"))
scaler = pickle.load(open("scaler.pkl", "rb"))

st.title("Diabetes Prediction App")

Pregnancies = st.number_input("Pregnancies", 0, 20, 1)
Glucose = st.number_input("Glucose", 0, 300, 120)
BloodPressure = st.number_input("BloodPressure", 0, 200, 70)
SkinThickness = st.number_input("SkinThickness", 0, 100, 20)
Insulin = st.number_input("Insulin", 0, 900, 80)
BMI = st.number_input("BMI", 0.0, 70.0, 25.0)
DPF = st.number_input("DiabetesPedigreeFunction", 0.0, 3.0, 0.5)
Age = st.number_input("Age", 1, 120, 30)

if st.button("Predict"):
    input_data = np.array([[Pregnancies, Glucose, BloodPressure,
                            SkinThickness, Insulin, BMI, DPF, Age]])
    input_scaled = scaler.transform(input_data)
    prediction = model.predict(input_scaled)[0]
    prob = model.predict_proba(input_scaled)[0][1]

    if prediction == 1:
        st.error(f"High Risk of Diabetes (Probability: {prob:.2f})")
    else:
        st.success(f"Low Risk of Diabetes (Probability: {prob:.2f})")
